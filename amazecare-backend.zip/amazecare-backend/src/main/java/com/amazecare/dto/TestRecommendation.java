package com.amazecare.dto;

import lombok.Data;

@Data
public class TestRecommendation {
    private String testName;
    private String remarks;
}
