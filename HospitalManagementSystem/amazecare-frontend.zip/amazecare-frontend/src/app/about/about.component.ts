import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
  sections = [
    {
      title: 'Who We Are',
      description: `An AmazeCare Hospital is a premier healthcare institution that blends advanced technology with human compassion. Our goal is to create a safe and patient-first experience where recovery is supported by both care and comfort.`
    },
    {
      title: 'Our Promise to You',
      description: `We pledge to provide personalized, timely, and high-quality care that respects your dignity. We focus on treating not just the illness but the whole person—physically, mentally, and emotionally.`
    },
    {
      title: 'The AmazeCare Difference',
      description: `We extend a legacy of trust through advanced medical tools, modern practices, and a culture of continuous improvement, driven by data and compassion.`
    },
    {
      title: 'Our Mission & Values',
      description: `We deliver ethical and accessible healthcare rooted in empathy, innovation, and excellence. We value honesty, compassion, and dignity in all that we do.`
    },
    {
      title: 'Care Beyond Medicine',
      description: `We look at the person behind the patient, supporting emotional and mental wellness alongside physical treatment through follow-ups, counseling, and education.`
    },
    {
      title: 'Excellence in Every Specialty',
      description: `From cardiology to orthopedics, each department is led by experts and designed for the best outcomes using safe practices and compassionate execution.`
    },
   
  ];
}
