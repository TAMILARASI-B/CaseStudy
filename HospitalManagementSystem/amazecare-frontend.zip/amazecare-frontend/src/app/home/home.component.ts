import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  images: string[] = [
    'assets/floatingimage4.jpg',
    'assets/floatingimage2.jpeg',
    'assets/floatingimage3.jpeg',
  ];

  currentIndex = 0;
  private intervalId: any;

  ngOnInit(): void {
    // Start auto-sliding every 2 seconds
    this.intervalId = setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.images.length;
    }, 2000);
  }

  ngOnDestroy(): void {
    // Clear the interval when the component is destroyed
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  selectImage(index: number): void {
    this.currentIndex = index;
  }
}
