import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from 'src/app/shared/services/admin.service';

@Component({
  selector: 'app-delete-patient',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './delete-patient.component.html',
  styleUrls: ['./delete-patient.component.css']
})
export class DeletePatientComponent implements OnInit {
  patientId: number = 0;
  patients: any[] = [];
  message: string = '';
  error: boolean = false;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.adminService.getAllPatientsForDropdown().subscribe({
      next: (data) => {
        this.patients = data;
      },
      error: () => {
        this.message = '❌ Failed to load patients.';
        this.error = true;
      }
    });
  }

  deletePatient() {
    if (!this.patientId || this.patientId <= 0) {
      this.message = 'Please select a valid patient.';
      this.error = true;
      return;
    }

    this.adminService.deletePatient(this.patientId).subscribe({
      next: () => {
        this.message = `✅ Patient with ID ${this.patientId} deleted successfully.`;
        this.error = false;
        this.patientId = 0;
        this.ngOnInit(); // refresh dropdown
      },
      error: (err) => {
        if (err.status === 404) {
          this.message = '❌ Patient with this ID not found.';
        } else {
          this.message = '❌ Something went wrong. Try again.';
        }
        this.error = true;
      }
    });
  }
}
