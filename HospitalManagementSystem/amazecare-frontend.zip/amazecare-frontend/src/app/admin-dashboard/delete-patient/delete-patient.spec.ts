import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePatientComponent } from './delete-patient.component';

describe('DeletePatient', () => {
  let component: DeletePatientComponent;
  let fixture: ComponentFixture<DeletePatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeletePatientComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeletePatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
