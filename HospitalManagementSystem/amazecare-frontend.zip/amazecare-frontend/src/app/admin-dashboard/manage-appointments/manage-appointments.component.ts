import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../shared/services/admin.service';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-manage-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-appointments.component.html',
  styleUrls: ['./manage-appointments.component.css']
})
export class ManageAppointmentsComponent implements OnInit {
  appointments: any[] = [];
  rescheduleDateTime: string = '';
  selectedAppointmentId: number | null = null;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.fetchAppointments();
  }

  fetchAppointments() {
    this.adminService.getAppointments().subscribe((data: any) => {
      this.appointments = data;
    });
  }

  startReschedule(id: number) {
    this.selectedAppointmentId = id;
    this.rescheduleDateTime = '';
  }

  updateAppointment() {
    if (this.selectedAppointmentId && this.rescheduleDateTime) {
      this.adminService.updateAppointment(this.selectedAppointmentId, {
        appointmentDateTime: this.rescheduleDateTime
      }).subscribe(() => {
        alert('Appointment rescheduled!');
        this.selectedAppointmentId = null;
        this.fetchAppointments();
      });
    }
  }

  cancelAppointment(id: number) {
    if (confirm('Cancel this appointment?')) {
      this.adminService.cancelAppointment(id).subscribe(() => {
        alert('Appointment cancelled');
        this.fetchAppointments();
      });
    }
  }
}
