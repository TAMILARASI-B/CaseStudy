import { Component } from '@angular/core';
import { AdminService } from '../../shared/services/admin.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface DoctorForm {
  name: string;
  specialty: string;
  experience: number;
  qualification: string;
  designation: string;
  username: string;
  email: string;
  password: string;
}

@Component({
  selector: 'app-add-doctor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.css']
})
export class AddDoctorComponent {
  doctor: DoctorForm = {
    name: '',
    specialty: '',
    experience: 0,
    qualification: '',
    designation: '',
    username: '',
    email: '',
    password: ''
  };

  successMessage = '';
  errorMessage = '';

  constructor(private adminService: AdminService) {}

  addDoctor() {
    const { name, specialty, experience, qualification, designation, username, password, email } = this.doctor;

    if (
      name.trim() &&
      specialty.trim() &&
      experience >= 0 &&
      qualification.trim() &&
      designation.trim() &&
      username.trim() &&
      email.trim() &&
      password.trim()
    ) {
      this.adminService.addDoctor(this.doctor).subscribe({
        next: (res: any) => {
          this.successMessage = typeof res === 'string' ? res : res?.message || ' Doctor is added successfully';
          this.errorMessage = '';
          this.resetForm();
        },
        error: (err) => {
          this.errorMessage =
            typeof err?.error === 'string'
              ? err.error
              : err?.error?.message || 'Failed to add doctor. Try again.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = 'Please fill in all fields.';
      this.successMessage = '';
    }
  }

  private resetForm() {
    this.doctor = {
      name: '',
      specialty: '',
      experience: 0,
      qualification: '',
      designation: '',
      username: '',
      email: '',
      password: ''
    };
  }
}
