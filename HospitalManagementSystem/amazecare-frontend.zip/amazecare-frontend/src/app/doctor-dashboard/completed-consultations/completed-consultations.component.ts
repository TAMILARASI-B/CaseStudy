import { Component, OnInit } from '@angular/core';
import { DoctorService } from '../../shared/services/doctor.service';
import { TokenStorageService } from '../../shared/services/token-storage.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-completed-consultations',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './completed-consultations.component.html',
  styleUrls: ['./completed-consultations.component.css']
})
export class CompletedConsultationsComponent implements OnInit {
  doctorId!: number;
  consultations: any[] = [];

  constructor(
    private doctorService: DoctorService,
    private tokenService: TokenStorageService
  ) {}

  ngOnInit(): void {
    const id = this.tokenService.getDoctorId();
    if (id && !isNaN(id)) {
      this.doctorId = id;
      this.fetchCompletedConsultations();
    } else {
      console.error(' Doctor ID is missing or invalid. Please login again.');
    }
  }

  fetchCompletedConsultations(): void {
    this.doctorService.getCompletedConsultations(this.doctorId).subscribe({
      next: (data: any[]) => {
        this.consultations = data;
      },
      error: (err) => {
        console.error('Failed to load completed consultations:', err);
      }
    });
  }
}
