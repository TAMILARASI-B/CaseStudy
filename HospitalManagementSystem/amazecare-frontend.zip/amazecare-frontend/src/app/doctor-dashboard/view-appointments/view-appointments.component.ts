import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { TokenStorageService } from 'src/app/shared/services/token-storage.service';

@Component({
  selector: 'app-view-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './view-appointments.component.html',
  styleUrls: ['./view-appointments.component.css']
})
export class ViewAppointmentsComponent implements OnInit {
  doctorId!: number;
  appointments: any[] = [];
  error: string = '';
  message: string = '';

  constructor(
    private doctorService: DoctorService,
    private tokenService: TokenStorageService
  ) {}

  ngOnInit(): void {
    const id = localStorage.getItem('amazecare-doctor-id'); // ✅ FIXED KEY
    if (id && !isNaN(Number(id))) {
      this.doctorId = parseInt(id, 10);
      this.fetchAppointments();
    } else {
      this.error = '❌ Doctor ID not found. Please login again.';
    }
  }

  fetchAppointments(): void {
    this.doctorService.getAppointments(this.doctorId).subscribe({
      next: (data: any[]) => {
        this.appointments = data;
        this.message = '';
        this.error = '';
      },
      error: () => {
        this.error = '❌ Failed to load appointments.';
        this.message = '';
      }
    });
  }

 cancelAppointment(id: number): void {
  this.doctorService.cancelAppointment(id).subscribe({
    next: (res) => {
      this.message = typeof res === 'string' ? res : (res.message || '✅ Appointment cancelled.');
      this.error = '';
      this.fetchAppointments();
    },
    error: () => {
      this.message = '';
      this.error = '❌ Failed to cancel appointment.';
    }
  });
}
}