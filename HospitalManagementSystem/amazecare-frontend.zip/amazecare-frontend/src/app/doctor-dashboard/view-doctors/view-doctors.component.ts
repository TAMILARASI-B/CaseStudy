import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DoctorService } from 'src/app/shared/services/doctor.service';
import { Doctor } from 'src/app/shared/models/doctor.model';

@Component({
  selector: 'app-view-doctors',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-doctors.component.html',
  styleUrls: ['./view-doctors.component.css']
})
export class ViewDoctorsComponent implements OnInit {
  doctors: Doctor[] = [];
  filteredDoctors: Doctor[] = [];
  specialties: string[] = [];
  selectedSpecialty: string = '';

  constructor(private doctorService: DoctorService) {}

  ngOnInit(): void {
    this.doctorService.getAllSpecialties().subscribe((specs: string[]) => {
      this.specialties = specs;
      if (specs.length > 0) {
        this.selectedSpecialty = specs[0];
        this.filterBySpecialty(this.selectedSpecialty);
      }
    });

    this.doctorService.getAllDoctors().subscribe((data: Doctor[]) => {
      this.doctors = data.map((doctor: Doctor) => {
        const formattedName = doctor.name.trim().replace(/\s+/g, '-').toLowerCase();
        doctor.photoUrl = `assets/dr-${formattedName}.jpg`;
        return doctor;
      });

      // Filter based on default specialty
      if (this.selectedSpecialty) {
        this.filterBySpecialty(this.selectedSpecialty);
      } else {
        this.filteredDoctors = this.doctors;
      }
    });
  }

  filterBySpecialty(specialty: string): void {
    this.selectedSpecialty = specialty;
    this.filteredDoctors = this.doctors.filter(
      d => d.specialty.toLowerCase() === specialty.toLowerCase()
    );
  }
}
