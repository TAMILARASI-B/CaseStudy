import { AppConfig } from './app.config.config';

describe('AppConfig', () => {
  it('should create an instance', () => {
    expect(new AppConfig()).toBeTruthy();
  });
});
