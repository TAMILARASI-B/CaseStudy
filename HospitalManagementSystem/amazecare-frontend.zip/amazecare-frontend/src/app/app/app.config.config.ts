export class AppConfig {
}
