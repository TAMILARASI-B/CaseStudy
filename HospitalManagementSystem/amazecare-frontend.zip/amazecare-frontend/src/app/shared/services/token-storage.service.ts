import { Injectable } from '@angular/core';

const TOKEN_KEY = 'amazecare-token';
const USERNAME_KEY = 'amazecare-username';
const ROLE_KEY = 'amazecare-role';
const USER_KEY = 'amazecare-user';
const USER_ID_KEY = 'amazecare-id'; // generic id (used only if needed)
const DOCTOR_ID_KEY = 'doctorId';
const PATIENT_ID_KEY = 'patientId';

@Injectable({
  providedIn: 'root'
})
export class TokenStorageService {

  signOut(): void {
    localStorage.clear();
  }

  saveToken(token: string): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.setItem(TOKEN_KEY, token);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  saveUsername(username: string): void {
    localStorage.removeItem(USERNAME_KEY);
    localStorage.setItem(USERNAME_KEY, username);
  }

  getUsername(): string | null {
    return localStorage.getItem(USERNAME_KEY);
  }

  saveRole(role: string): void {
    localStorage.removeItem(ROLE_KEY);
    localStorage.setItem(ROLE_KEY, role);
  }

  getRole(): string | null {
    return localStorage.getItem(ROLE_KEY);
  }

  saveUser(user: any): void {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  getUser(): any {
    const user = localStorage.getItem(USER_KEY);
    return user ? JSON.parse(user) : null;
  }

  saveUserId(id: string): void {
    localStorage.removeItem(USER_ID_KEY);
    localStorage.setItem(USER_ID_KEY, id);
  }

  getUserId(): string | null {
    return localStorage.getItem(USER_ID_KEY);
  }

  getUserDetails(): any {
    return {
      token: this.getToken(),
      username: this.getUsername(),
      role: this.getRole(),
      id: this.getUserId()
    };
  }

  // ✅ New: Save doctor ID
  saveDoctorId(doctorId: number): void {
    localStorage.setItem(DOCTOR_ID_KEY, doctorId.toString());
  }

  // ✅ New: Get doctor ID
  getDoctorId(): number | null {
    const id = localStorage.getItem(DOCTOR_ID_KEY);
    return id ? Number(id) : null;
  }

  // ✅ New: Save patient ID
  savePatientId(patientId: number): void {
    localStorage.setItem(PATIENT_ID_KEY, patientId.toString());
  }

  // ✅ New: Get patient ID
  getPatientId(): number | null {
    const id = localStorage.getItem(PATIENT_ID_KEY);
    return id ? Number(id) : null;
  }
}
