// src/app/shared/services/admin.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { TokenStorageService } from './token-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = `${environment.apiUrl}/admin`;

  constructor(private http: HttpClient, private tokenStorage: TokenStorageService) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.tokenStorage.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  // ---------- Patient Management ----------
  getPatients(): Observable<any> {
    return this.http.get(`${this.apiUrl}/get-all-patients`, {
      headers: this.getAuthHeaders()
    });
  }

  addPatient(patient: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/add-patient`, patient, {
      headers: this.getAuthHeaders()
    });
  }

  deletePatient(patientId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete-patient/${patientId}`, {
      headers: this.getAuthHeaders()
    });
  }

  // ---------- Doctor Management ----------
  getDoctors(): Observable<any> {
    return this.http.get(`${this.apiUrl}/get-all-doctors`, {
      headers: this.getAuthHeaders()
    });
  }

  addDoctor(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/add-doctor`, data, {
      headers: this.getAuthHeaders()
    });
  }

  deleteDoctor(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete-doctor/${id}`, {
      headers: this.getAuthHeaders()
    });
  }

  // ---------- Appointment Management ----------
  getAppointments(): Observable<any> {
    return this.http.get(`${this.apiUrl}/get-all-appointments`, {
      headers: this.getAuthHeaders()
    });
  }

  updateAppointment(id: number, data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update-appointment/${id}`, data, {
      headers: this.getAuthHeaders()
    });
  }

  cancelAppointment(id: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/cancel-appointment/${id}`, {}, {
      headers: this.getAuthHeaders()
    });
  }
 getAllPatientsForDropdown(): Observable<any[]> {
  return this.http.get<any[]>(`${this.apiUrl}/patients/id-name`);
}



}
