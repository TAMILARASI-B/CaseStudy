import { Routes } from '@angular/router';

// Auth
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';

// Admin Dashboard Components
import { AdminHomeComponent } from './admin-dashboard/admin-home.component';
import { AddDoctorComponent } from './admin-dashboard/add-doctor/add-doctor.component';
import { AddPatientComponent } from './admin-dashboard/add-patient/add-patient.component';
import { ManageDoctorsComponent } from './admin-dashboard/manage-doctors/manage-doctors.component';
import { ManagePatientsComponent } from './admin-dashboard/manage-patients/manage-patients.component';
import { ManageAppointmentsComponent } from './admin-dashboard/manage-appointments/manage-appointments.component';
import { DeleteDoctorComponent } from './admin-dashboard/delete-doctor/delete-doctor.component';

// Doctor Dashboard Components
import { ViewAppointmentsComponent as DoctorAppointments } from './doctor-dashboard/view-appointments/view-appointments.component';
import { AddPrescriptionComponent } from './doctor-dashboard/add-prescription/add-prescription.component';
import { CompletedConsultationsComponent } from './doctor-dashboard/completed-consultations/completed-consultations.component';
import { DoctorHomeComponent } from './doctor-dashboard/doctor-home.component';

// Patient Dashboard Components
import { BookAppointmentComponent } from './patient-dashboard/book-appointment/book-appointment.component';
import { ViewAppointmentsComponent as PatientAppointments } from './patient-dashboard/view-appointments/view-appointments.component';
import { MedicalHistoryComponent } from './patient-dashboard/medical-history/medical-history.component';

// Guards
import { authGuard } from './shared/guards/auth.guard';
import { roleGuard } from './shared/guards/role.guard';


import { ForgetPasswordComponent } from './auth/forget-password/forget-password.component';
export const routes: Routes = [
  // 🌟 Public Pages
  { path: '', loadComponent: () => import('./home/home.component').then(m => m.HomeComponent) },
  { path: 'about', loadComponent: () => import('./about/about.component').then(m => m.AboutComponent) },
  { path: 'contact', loadComponent: () => import('./contact/contact.component').then(m => m.ContactComponent) },

  // 🌟 Auth
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forget-password', component: ForgetPasswordComponent },
  // 🌟 Admin Dashboard
  { path: 'admin-dashboard', component: AdminHomeComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  { path: 'admin-dashboard/add-doctor', component: AddDoctorComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  { path: 'admin-dashboard/add-patient', component: AddPatientComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  { path: 'admin-dashboard/manage-doctors', component: ManageDoctorsComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  { path: 'admin-dashboard/manage-patients', component: ManagePatientsComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  { path: 'admin-dashboard/manage-appointments', component: ManageAppointmentsComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  { path: 'admin-dashboard/delete-doctor', component: DeleteDoctorComponent, canActivate: [authGuard, roleGuard], data: { role: 'ADMIN' } },
  {
    path: 'admin-dashboard/delete-patient',
    loadComponent: () => import('./admin-dashboard/delete-patient/delete-patient.component').then(m => m.DeletePatientComponent),
    canActivate: [authGuard, roleGuard],
    data: { role: 'ADMIN' }
  },

  // 🌟 Doctor Dashboard
  { path: 'doctor-dashboard/home', component: DoctorHomeComponent, canActivate: [authGuard, roleGuard], data: { role: 'DOCTOR' } },
  { path: 'doctor-dashboard/view-appointments', component: DoctorAppointments, canActivate: [authGuard, roleGuard], data: { role: 'DOCTOR' } },
  { path: 'doctor-dashboard/add-prescription', component: AddPrescriptionComponent, canActivate: [authGuard, roleGuard], data: { role: 'DOCTOR' } },
  { path: 'doctor-dashboard/completed-consultations', component: CompletedConsultationsComponent, canActivate: [authGuard, roleGuard], data: { role: 'DOCTOR' } },
  { path: 'doctor-dashboard', redirectTo: 'doctor-dashboard/home', pathMatch: 'full' },

  // 🌟 Patient Dashboard
  {
    path: 'patient-dashboard',
    loadComponent: () => import('./patient-dashboard/patient-home.component').then(m => m.PatientHomeComponent),
    canActivate: [authGuard, roleGuard],
    data: { role: 'PATIENT' }
  },
  { path: 'patient-dashboard/book-appointment', component: BookAppointmentComponent, canActivate: [authGuard, roleGuard], data: { role: 'PATIENT' } },
  { path: 'patient-dashboard/view-appointments', component: PatientAppointments, canActivate: [authGuard, roleGuard], data: { role: 'PATIENT' } },
  { path: 'patient-dashboard/medical-history', component: MedicalHistoryComponent, canActivate: [authGuard, roleGuard], data: { role: 'PATIENT' } },
  {
    path: 'patient-dashboard/cancel-appointment',
    loadComponent: () => import('./patient-dashboard/cancel-appointment.component').then(m => m.CancelAppointmentComponent),
    canActivate: [authGuard, roleGuard],
    data: { role: 'PATIENT' }
  },

  // 🌟 Doctors Page
  { path: 'doctors', loadComponent: () => import('./doctor-dashboard/view-doctors/view-doctors.component').then(m => m.ViewDoctorsComponent) },


];
