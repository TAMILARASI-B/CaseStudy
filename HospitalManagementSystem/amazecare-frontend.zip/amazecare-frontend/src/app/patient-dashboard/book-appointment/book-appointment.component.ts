// src/app/patient-dashboard/book-appointment/book-appointment.component.ts

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PatientService } from '../../shared/services/patient.service';
import { TokenStorageService } from '../../shared/services/token-storage.service';

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css']
})
export class BookAppointmentComponent implements OnInit {
  doctors: any[] = [];
  message: string = '';
  error: string = '';
  patientId: number = 0;

  appointment = {
    doctorId: 0,
    symptoms: '',
    appointmentDate: '',
    appointmentTime: ''
  };

  constructor(
    private patientService: PatientService,
    private tokenStorage: TokenStorageService
  ) {}

  ngOnInit(): void {
    const storedId = localStorage.getItem('amazecare-patient-id');
    if (storedId) {
      this.patientId = parseInt(storedId, 10);
    } else {
      this.error = ' Patient ID not found. Please log in again.';
      this.message = '';
      return;
    }

    this.fetchDoctors();
  }

  fetchDoctors(): void {
    this.patientService.getDoctors().subscribe({
      next: (data: any[]) => {
        this.doctors = data;
      },
      error: () => {
        this.error = ' Failed to load doctors.';
        this.message = '';
      }
    });
  }

  bookAppointment(): void {
    const { doctorId, symptoms, appointmentDate, appointmentTime } = this.appointment;

    if (doctorId && this.patientId && appointmentDate && appointmentTime && symptoms.trim() !== '') {
      const preferredDateTime = `${appointmentDate}T${appointmentTime}:00`;

      const payload = {
        doctorId: Number(doctorId),
        patientId: this.patientId,
        symptoms,
        preferredDateTime
      };

      console.log("Payload sent:", payload);

      this.patientService.bookAppointment(payload).subscribe({
        next: (response: any) => {
          console.log("Server response:", response);

          if (response && response.status === false) {
            this.error = ' Server rejected the appointment.';
            this.message = '';
          } else {
            this.message = 'Appointment booked successfully!';
            this.error = '';
            this.appointment = {
              doctorId: 0,
              symptoms: '',
              appointmentDate: '',
              appointmentTime: ''
            };
          }
        },
        error: (err) => {
          console.error('HTTP Error:', err);
          this.error = ' Failed to book appointment. Please try again.';
          this.message = '';
        }
      });
    } else {
      this.error = 'Please complete all required fields.';
      this.message = '';
    }
  }
}
