import { Component, OnInit } from '@angular/core';
import { PatientService } from '../../shared/services/patient.service';
import { CommonModule } from '@angular/common';
import { TokenStorageService } from 'src/app/shared/services/token-storage.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-view-appointments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-appointments.component.html',
  styleUrls: ['./view-appointments.component.css']
})
export class ViewAppointmentsComponent implements OnInit {
  patientId!: number;
  upcomingAppointments: any[] = [];
  error: string = '';
  message: string = '';

  constructor(
    private patientService: PatientService,
    private tokenService: TokenStorageService
  ) {}

  ngOnInit(): void {
    const id = localStorage.getItem('amazecare-patient-id');
    if (id) {
      this.patientId = parseInt(id, 10);
      this.fetchAppointments();
    } else {
      this.error = 'Patient ID not found. Please login again.';
    }
  }

  fetchAppointments() {
    this.patientService.getAppointments(this.patientId).subscribe({
      next: (appointments: any[]) => {
        this.upcomingAppointments = appointments.filter(a => a.status !== 'COMPLETED');
        this.error = '';
      },
      error: () => {
        this.error = '❌ Failed to load appointments.';
      }
    });
  }

 cancelAppointment(appointmentId: number): void {
  this.patientService.cancelAppointment(appointmentId).subscribe({
    next: (res: any) => {
      this.message = res.message || '✅ Appointment cancelled successfully.';
      this.error = '';
      this.fetchAppointments();
    },
    error: (err) => {
      this.error = err?.error?.message || '❌ Failed to cancel appointment.';
      this.message = '';
    }
  });
}
}
