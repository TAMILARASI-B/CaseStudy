export const environment = {
  production: true,
  apiUrl: 'https://your-production-url.com/api'
};
